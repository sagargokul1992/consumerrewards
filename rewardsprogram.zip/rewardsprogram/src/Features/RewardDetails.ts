interface RewardDetials {
  monthName: string;
  totalpoints: number;
}

export default RewardDetials;
