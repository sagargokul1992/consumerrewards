interface TransactionType {
  transactionid: number;
  transactionDate: string;
  amount: number;
  remarks: string;
  currency: string;
}

export default TransactionType;
