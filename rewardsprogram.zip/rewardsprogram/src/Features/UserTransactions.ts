const user = [
  {
    id: 1234,
    transactions: [
      {
        transactionid: 1,
        transactionDate: "2020-01-01",
        amount: 120,
        remarks: "Walmart",
        currency: "USD"
      },
      {
        transactionid: 2,
        transactionDate: "2020-01-01",
        amount: 120,
        remarks: "Costco",
        currency: "USD"
      },
      {
        transactionid: 3,
        transactionDate: "2020-02-02",
        amount: 120,
        remarks: "Walmart",
        currency: "USD"
      },
      {
        transactionid: 4,
        transactionDate: "2020-02-02",
        amount: 120,
        remarks: "Costco",
        currency: "USD"
      }
    ]
  },
  {
    id: 2345,
    transactions: [
      {
        transactionid: 1,
        transactionDate: "2020-01-01",
        amount: 5,
        remarks: "Walmart",
        currency: "USD"
      },
      {
        transactionid: 2,
        transactionDate: "2020-01-01",
        amount: 57,
        remarks: "Costco",
        currency: "USD"
      },
      {
        transactionid: 3,
        transactionDate: "2020-02-02",
        amount: 32,
        remarks: "Walmart",
        currency: "USD"
      },
      {
        transactionid: 4,
        transactionDate: "2020-03-02",
        amount: 23,
        remarks: "Costco",
        currency: "USD"
      }
    ]
  }
];

export default user;
