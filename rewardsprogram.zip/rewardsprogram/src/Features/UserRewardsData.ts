interface UserRewardsData {}

export default UserRewardsData;
